The best way to run and compile this code is to import it directly into Eclipse.

Open Eclipse, 
File -> Import,
Select "Existing project into workspace" under the "General" folder
Browse to the "CSCD350FinalProjectCode"folder
Finish the process.

Run as you would any other program in eclipse.
