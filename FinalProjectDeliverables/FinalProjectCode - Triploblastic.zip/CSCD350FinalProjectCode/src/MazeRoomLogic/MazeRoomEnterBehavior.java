package MazeRoomLogic;

public interface MazeRoomEnterBehavior {
	public boolean enter();
}
