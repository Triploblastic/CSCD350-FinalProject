package MazeRoomLogic;

public class NullEffect implements PlayerEffect {

	@Override
	public void ApplyEffect() {
		// this does nothing intentionally
	}

}
