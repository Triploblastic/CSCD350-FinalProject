package MazeRoomLogic;

public interface PlayerEffect {
	public void ApplyEffect();
}
