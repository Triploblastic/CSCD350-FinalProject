package MazeRoomLogic;

public class TrueRoomEnterBehavior implements MazeRoomEnterBehavior {

	@Override
	public boolean enter() {
		return true;
	}

}
