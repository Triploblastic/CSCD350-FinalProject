package MazeRoomLogic;

public class WallRoomEnterBehavior implements MazeRoomEnterBehavior {

	//you can't enter a wall dum dum
	@Override
	public boolean enter() {
		// TODO Auto-generated method stub
		return false;
	}

}
