package GameOverLogic;

public interface GameOverBehavior {
	public void Behave();
}
