package MazeGeneration;

public class EnumMazeTester {
	
	public static void main(String[] args) {
		EnumMaze m1 = new EnumMaze(7);
		System.out.println(m1.toString());
	}

}
